# scraper.py
import aiohttp
import asyncio
from re import compile
from typing import Set

TIMEOUT: int = 15
CONCURRENCY = 30
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36"

# regex menangkap "ip:port" (validasi port sampai 65535)
REGEX = compile(
    r"(?:^|\D)?(("
    + r"(?:[1-9]|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])"
    + r"\." + r"(?:\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])"
    + r"\." + r"(?:\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])"
    + r"\." + r"(?:\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])"
    + r"):" + r"(?:\d|[1-9]\d{1,3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])"
    + r")(?:\D|$)"
)

# tempat menyimpan hasil sementara
proxies_set: Set[str] = set()
errors: list = []

sem = asyncio.Semaphore(CONCURRENCY)


async def fetch_and_extract(url: str, session: aiohttp.ClientSession):
    try:
        async with sem:
            async with session.get(url, headers={'User-Agent': USER_AGENT}, timeout=aiohttp.ClientTimeout(total=TIMEOUT)) as resp:
                text = await resp.text(errors='ignore')
                for m in REGEX.finditer(text):
                    proxies_set.add(m.group(1))
    except Exception as e:
        errors.append(f"[FETCH ERROR] {url} -> {e}")


def extract_from_line(line: str):
    # langsung cari ip:port di baris (berguna jika sources.txt berisi proxy langsung)
    for m in REGEX.finditer(line):
        proxies_set.add(m.group(1))


async def main():
    # baca sources.txt
    with open('sources.txt', 'r', encoding='utf-8', errors='ignore') as f:
        lines = [ln.strip() for ln in f.readlines() if ln.strip()]

    # buat session tunggal untuk semua request
    async with aiohttp.ClientSession() as session:
        tasks = []
        for ln in lines:
            ln_lower = ln.lower()
            if ln_lower.startswith('http://') or ln_lower.startswith('https://'):
                # treat as URL -> download
                tasks.append(asyncio.create_task(fetch_and_extract(ln, session)))
            else:
                # treat as inline content (could be "ip:port", "ip:port:Country", atau teks lain)
                extract_from_line(ln)

        if tasks:
            await asyncio.gather(*tasks)

    # tulis hasil unik ke http.txt (sorted supaya rapi)
    unique_list = sorted(proxies_set, key=lambda x: tuple(int(p) if p.isdigit() else 0 for p in x.split(':')))

    with open('http.txt', 'w', encoding='utf-8') as out:
        for p in unique_list:
            out.write(f"{p}\n")

    # tulis log error jika ada
    if errors:
        with open('errors.txt', 'a', encoding='utf-8') as ef:
            for e in errors:
                ef.write(e + "\n")

    print(f"[DONE] Total unique proxies: {len(unique_list)} -> saved to http.txt")


if __name__ == "__main__":
    asyncio.run(main())
