const tesseract = require('tesseract.js'); // ORC
const { sleep, mouser } = require('./utils');
const { checkTurnstile } = require('./turnstile');
const { execSync } = require('child_process');
const fs = require('fs');

// Configurations for detecting different challenge types
const challengeConfigs = [
  {
    name: 'SafeLine Captcha',
    detect: async (page, content, title) => {
      if (content.includes('challenge/v2/challenge.js')) {
        console.log("[INFO] Detected Protection ~ SafeLine Captcha");
        return true;
      }
      return false
    },
    type: 'captcha',
    safelineSelector: '#sl-check',
    solve: async function(page, data) {
      const element = await page.$(this.safelineSelector);
      data.startTime = Date.now();
      if (element) {
        console.log(`[INFO] Found Captcha element: ${this.safelineSelector}`);
        const captchabox = await element.boundingBox();
        if (captchabox) {
          const x = captchabox.x + captchabox.width / 2;
          const y = captchabox.y + captchabox.height / 2;
          await page.mouse.click(x, y, { delay: Math.floor(Math.random() * 40) });
          await sleep(1);
        }
      } else {
       console.log(`[WARN] Captcha element '${this.safelineSelector}" not found`);
       return;
      }
    }
  },
  {
    name: 'Cloudflare Turnstile',
    detect: async (page, content, title, proxy) => content.includes('turnstile/v0/api.js'),
    type: 'cloudflare turnstile',
    solve: async (page, data, proxy) => {
      data.startTime = Date.now();
      console.log(`[INFO] Detected Cloudflare Turnstile - ${proxy}`)
      const result = await checkTurnstile({ page });
      await sleep(0.8);
    }
  },
  {
    name: 'Cdnfly Click',
    detect: async (page, content, title) =>
      content.includes('_guard/click.js') || content.includes('js=click_html'),
    type: 'click',
    solve: async function (page, data, proxy) {
      console.log(`[INFO] Detected protection CdnFly Click(Legacy) - ${proxy}`);
      const el = await page.$('h#access').catch(() => null);
      if (el) {
//        await el.click();
        await sleep(1)
      } else {
//        console.warn('[WARN] Click element "#access" not found');
        return "invalid";
      }
    }
  },
  {
    name: 'Cdnfly Slider',
    detect: async (page, content, title) => {
      const el = await page.$('#slider').catch(() => null);
      if (el) {
        return true;
      }
      return false;
    },
    type: 'slider',
    cdnflySlider: '#slider',
    solve: async function (page, data) {
      console.log('[INFO] Detected Protection ~ Cdnfly Slider ');
      const slider = await page.$(this.cdnfllySlider).catch(() => null);
      if (slider) {
        console.log(`[INFO] Found Slider element: ${this.cdnflySlider}`);
        const box = await slider.boundingBox();
        if (box && box.width > 10 && box.height > 10) {
          await sleep(3);
          console.log('[DEBUG] Solving slider with mouse drag');
          await page.mouse.move(box.x + 5, box.y + box.height / 2);
          await page.mouse.down();
          await page.mouse.move(box.x + box.width + 130, box.y + box.height / 2, { steps: 30 });
          await page.mouse.up();
          await sleep(1);
          return;
        }
      }
      console.log('[WARN] Slider element "${this.cdnflySlider}" not found');
    }
  },
  {
    name: 'Generic Slider',
    detect: async function(page, content, title, proxy) {
      for (const sel of this.sliderSelectors) {
        const el = await page.$(sel).catch(() => null);
        if (el) {
          console.log(`[INFO] Detected Protection ~ Generic Slider ${proxy}`);
          return true;
        }
      }
      return false;
    },
    type: 'slider',
    sliderSelectors: ['#handler', '.slider-handler', '.slider-button'],
    solve: async function (page, data) {
      for (const sel of this.sliderSelectors) {
        const slider = await page.$(sel).catch(() => null);
        if (slider) {
//          console.log(`[INFO] Found Slider element: ${sel}`)
          const box = await slider.boundingBox();
          const sliderBox = await slider.boundingBox();
          if (box && box.width > 10 && box.height > 10) {
//            console.log(`[DEBUG] Solving slider with mouse drag`);
            await page.mouse.move(sliderBox.x + 5, sliderBox.y + sliderBox.height / 2);
            await page.mouse.down();
            await page.mouse.move(sliderBox.x + sliderBox.width + 200, sliderBox.y + sliderBox.height / 2, { steps: 30 });
            await page.mouse.up();
            await sleep(3);
            return;
          }
        }
      }
      console.log('[WARN] No slider element found for Generic Slider ');
    }
  },
  {
    name: 'Generic Click Challenge',
    detect: async function(page, content, title) {
      for (const sel of this.clickSelectors) {
        const el = await page.$(sel).catch(() => null);
        if (el) {
          console.log(`[INFO] Detected Generic click challenge`);
          return true;
        }
      }
      return false;
    },
    type: 'click challenge',
    clickSelectors: [
      '.captcha-btn', '.btn-slide', '.btn-drag', '#captcha', '.click-captcha',
      '#captcha-verify', '.captcha-click', '.captcha-widget', '.captcha-frame', 
      '.captcha-btn-click', '.captcha-check', '#captcha-challenge', '.captcha-submit',
      '.captcha-btn-submit', 'iframe["captcha"]', '.captcha-container', '.checkbox-container'
    ],
    solve: async function(page, data) {
      for (const sel of this.clickSelectors) {
        const el = await page.$(sel).catch(() => null);
        if (el) {
          console.log(`[INFO] Found click challenge element: ${sel}`);
          await el.click();
          await sleep(1);
          return;
        }
      }
      console.log('[WARN] No click element found for Generic click challenge');
    }
  },
  {
    name: 'Generic Text-Based Captcha (with OCR)',
    detect: async (page, content, title) => {
      const imgSelectors = [
        'img[src*="captcha"]',
        'img.captcha-img',
        '.captcha-image',
        'img[src*="verify"]',
        'img[src*="secure"]',
        'img[alt*="captcha"]',
        '#ui-captcha-image',
      ];

      const inputSelectors = [
        'input[type="text"]',
        'input[type="captcha"]',
        '.captcha-input',
        '#captcha-input',
        'input[name*="CaptchaCode"]',
        'input[name*="CLOUD_WAF_CAPTCHA_CODE"]',
      ];

      let imageFound = false;
      for (const sel of imgSelectors) {
        const el = await page.$(sel).catch(() => null);
        if (el) {
          const box = await el.boundingBox().catch(() => null);
          if (box && box.width > 50 && box.height > 20) {
            console.log(`[INFO] Found CAPTCHA image element: ${sel}`);
            imageFound = true;
            break;
          }
        }
      }

      let inputFound = false;
      for (const sel of inputSelectors) {
        const el = await page.$(sel).catch(() => null);
        if (el) {
          const box = await el.boundingBox().catch(() => null);
          if (box && box.width > 50 && box.height > 15) {
            console.log(`[INFO] Found CAPTCHA input element: ${sel}`);
            inputFound = true;
            break;
          }
        }
      }

      return imageFound && inputFound;
    },
    type: 'text-based captcha',
    solve: async function (page, data) {
      console.log('[INFO] Solving Generic Text-Based CAPTCHA with OCR');

      const imgSelectors = [
        'img[src*="captcha"]',
        'img.captcha-img',
        '.captcha-img',
        '.captcha-image',
        '#captcha-img',
        '#captcha-image',
        '.verify-captcha',
        'img[src*="verify"]',
        'img[src*="secure"]',
        'img[alt*="captcha"]',
        '#ui-captcha-image',
      ];

      const inputSelectors = [
        'input[type="captcha"]',
        '.captcha-input',
        '#captcha-input',
        'input[name*="CaptchaCode"]',
        'input[name*="CLOUD_WAF_CAPTCHA_CODE"]',
      ];

      let image = null;
      for (const sel of imgSelectors) {
        image = await page.$(sel).catch(() => null);
        if (image) break;
      }

      if (!image) {
        console.warn('[WARN] CAPTCHA image not found');
        return;
      }

      const captchaPath = 'captcha.png';
      await image.screenshot({ path: captchaPath });

      const { data: { text } } = await tesseract.recognize(captchaPath, 'eng').catch(e => {
        console.error('[ERROR] OCR failed:', e.message);
        return { data: { text: '' } };
      });

      const cleaned = text.replace(/[^a-zA-Z0-9]/g, '').trim();
      console.log('[DEBUG] OCR result:', cleaned);

      if (!cleaned) {
        console.warn('[WARN] OCR returned empty or invalid text');
        return;
      }
      let inputSel = null;
      for (const sel of inputSelectors) {
        const el = await page.$(sel).catch(() => null);
        if (el) {
          inputSel = sel;
          break;
        }
      }


      if (!inputSel) {
        console.warn('[WARN] CAPTCHA input field not found');
        return;
      }
      await page.click(inputSel);
      await page.type(inputSel, cleaned, { delay: 50 });
      await sleep(1);

      const submitSelectors = [
        'input[type="submit"]',
        'button[type="button"]',
        'button[type="submit"]',
        '#captcha-submit',
        '.captcha-submit',
        '.btn.btn-success',
      ];

      for (const sel of submitSelectors) {
        const submitBtn = await page.$(sel).catch(() => null);
        if (submitBtn) {
          console.log(`[DEBUG] Clicking submit button: ${sel}`);
          await submitBtn.click({ delay: 50 });
          await sleep(2);
          return;
        }
      }

      console.warn('[WARN] No submit button found after CAPTCHA input');
    }
  },
  {
    name: 'JS Challenge (BlazingFast/Sucuri/VShield/etc)',
    detect: async (page, content, title) => [
      'You are being redirected', 'DDoS-Guard', 'Just a moment please...', 'Vercel Security Checkpoint'
    ].some(t => title.includes(t)) || /vshield\.pro/.test(content),
    type: 'mouse',
  }
];

async function JsChallenge(page, content, title, data, proxy) {
  for (const cfg of challengeConfigs) {
    let detected = false;

    try {
      detected = await cfg.detect.call(cfg, page, content, title, proxy);
    } catch (e) {
      console.log(`[ERROR] Detection error in ${cfg.name}:`, e.message);
      continue;
    }

    if (detected) {
//      console.log('[INFO] Detected:', cfg.name);
      data.startTime = Date.now();

      if (title === 'You are being redirected') {
        console.log('[INFO] Detected Protection ~ Sucuri JS Challenge');

      } else if (title.includes('DDoS-Guard')) {
        console.log('[INFO] Detected Protection ~ DDOS-Guard JS Challenge');

      } else if (title.includes('Just a moment please...')) {
        console.log('[INFO] Detected Protection ~ BlazingFast JS Challenge');

      } else if (title.includes('Vercel Security Checkpoint')) {
        console.log('[INFO] Detected Protection ~ Vercel Attack Challenge Mode');

      } else if (content.includes('vddosw3data.js')) {
        console.log('[INFO] Detected Protection ~ React js')
        await mouser(page);
        return;

      } else if (content.includes("fw.vshield.pro/v2/bot-detector.js")) {
        console.log('[INFO] Detected protection ~ VShield');
        await mouser(page);
        return;
      }
      if (cfg.solve) {
        const solve = await cfg.solve.call(cfg, page, data, proxy);
        if (solve) {
          return true;
        } else {
         return false;
        }
      }

      if (cfg.type === 'click') {
        for (const sel of cfg.clickSelectors) {
          const el = await page.$(sel).catch(() => null);
          if (el) {
            await el.click({ delay: Math.floor(Math.random() * 50) });
            await sleep(2);
            if (cfg.postHandler) await cfg.postHandler(page);
            break;
          }
        }
        return;
      }

      if (cfg.type === 'mouse') {
        await mouser(page);
        await sleep(3);
        return;
      }
    }
  }

  console.log('[INFO] No challenge detected or all handlers failed.');
  return "invalid";
}

module.exports = JsChallenge;
